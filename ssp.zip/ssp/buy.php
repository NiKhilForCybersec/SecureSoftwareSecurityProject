<?php

if(!isset($pname))
{
    header('Location:myorder.php');
}
session_start();
//echo $_SESSION['username'];
if(!isset($_SESSION['username']))
{
    header('Location:ulogin.php');
   
    exit(0);
    
}
else
{
    require_once 'database.php';
    $name = $_SESSION['username'];
    $pname = $_POST['pname'];
    $proname = mysqli_real_escape_string($con,$pname);
    $query = "INSERT INTO `orders` (username, pname) VALUES ('$name', '$proname')";
    
    $result = mysqli_query($con,$query);
    if($result)
    {
        echo $_POST['pname'];
        echo "s";
        
        
    }else
        {
        echo 'f';   
        }
    }
    //header('Location:order.php');

?>