
<?php 
session_start();
$host="localhost";
$user="root";
$password="";
$db="ssp";

$con=mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);

if(isset($_POST['submit'])){
    
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="select * from login where username='".$uname."'AND password='".$password."' limit 1";
    
    $result=mysqli_query($con,$sql);
    
    if(mysqli_num_rows($result)==1){
        echo " You Have Successfully Logged in";
		$_SESSION['username']= $uname;
		
        header('Location:index.php');
		
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        header('Location:login.php');
		exit();
    }
        
}
?>     
 


<!DOCTYPE html>
<html>
<head>
	<title> Login </title>
	<link rel="stylesheet" a href="css\style.css">
	
</head>
<body>
	<div class="container">
	<img src="images/login.gif"/>
		<form method="POST" action="#">
			<div class="form-input">
				<input type="text" name="username" placeholder="Enter the User Name"/>	
			</div>
			<div class="form-input">
				<input type="password" name="password" placeholder="password"/>
			</div>
			<input type="submit" name="submit" value="LOGIN" class="btn-login"/>
		</form>
	</div>

<?php
session_unset();
session_destroy();
?>
</body>
</html>