
<?php
              
              
              $host="localhost";
              $user="root";
              $password="";
              $db="ssp";
              
              $con=mysqli_connect($host,$user,$password);
              mysqli_select_db($con,$db);
            
             if(!$con)
             {
               echo('Could not get data: ' . mysqli_error());
             }
 
             mysqli_close($con);
             ?>