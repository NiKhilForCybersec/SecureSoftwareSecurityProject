<?php    

if (isset($_GET['query'])) {

    // Retrieve data
    include 'database.php';

    $query = $_GET['query'];
    $find = stripslashes($query);
    $find = strtoupper($query); 
    $find = strip_tags($query); 
    $find = mysqli_real_escape_string ($con,$query);

    

    if (is_string($find)){

        $query = "SELECT pname,id,pdesc FROM product where pname LIKE '%$find%';";
        $data = mysqli_query($con,$query) or die('<pre>' . mysqli_error() . '</pre>' );
       
        echo "<h1> Search Result:</h1>";
        echo "<table border=1 width=500>";
             echo "<td>"; echo "Product Search:".$_GET['query']; echo "</td>";
        while($result = mysqli_fetch_array( $data)) 
{
        
            echo "<tr width='100'>";
                      
                      echo "<td>".$result['pname']."</td>";
                      $link = $result['id'];
                      echo "<td>" ; echo "<a href=view.php?id=$link>"; echo "View Product"; echo "</a>";
                      echo "</tr>";
                      
          

        
        }
        echo "</table>"; 
    }
}
?>
