<?php

              
              
              $host="localhost";
              $user="root";
              $password="";
              $db="sssp";
              
              $con=mysqli_connect($host,$user,$password);
              mysqli_select_db($con,$db);
            
             if(!$con)
             {
               echo('Could not get data: ' . mysqli_error());
             }
 
if ($_GET['action'] == "add")
{
		if (!is_numeric($_POST['pid']))
		{
		
			header('Location:product.php');	
			exit(0);
		}
		else 
			{
				$pid = strip_tags($_POST['pid']);
				$name = strip_tags($_POST['cname']);
				$email=strip_tags($_POST['cemail']);
				$comment=strip_tags($_POST['ccomment']);

				$sql = "INSERT INTO comments (pid, cname, cemail, ccomment) VALUES (?, ?, ?, ?)";
				$stmt = $con->prepare($sql);
                                
				if($stmt)
				{
					$stmt->bind_param("isss",$pid,$name,$email,$comment);
					$stmt->execute();
					header('Location:view.php?id='.$pid);
					//$res = $stmt->get_result();

					
				}
				else
				{
					echo "error" ;
				}	

			}
}

else {
			 
		header('Location:view.php');
	}


mysqli_close($con);
?>