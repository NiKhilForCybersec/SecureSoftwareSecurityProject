
<?php 
session_start();
$host="localhost";
$user="root";
$password="";
$db="sssp";

$con=mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);
function reCaptcha($recaptcha)
{
	$secret = "6LeeJGMbAAAAADKA1aIq6LdPCYpi4lmjIz9j9T1-";
	$ip = $_SERVER['REMOTE_ADDR'];
  
	$postvars = array("secret"=>$secret, "response"=>$recaptcha, "remoteip"=>$ip);
	$url = "https://www.google.com/recaptcha/api/siteverify";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
	$data = curl_exec($ch);
	curl_close($ch);
  
	return json_decode($data, true);
  }

if(isset($_POST['submit'])){
	$uname=mysqli_real_escape_string($con,$_POST['username']);
    $password=mysqli_real_escape_string($con,$_POST['password']);
	$recaptcha = $_POST['g-recaptcha-response'];
  $res = reCaptcha($recaptcha);
    
    $sql="select * from login where username='".$uname."'AND password='".$password."' limit 1";
    
    $result=mysqli_query($con,$sql);
    
    if(mysqli_num_rows($result)==1 )
	{
		if($res['success'])
		{
			  echo " You Have Successfully Logged in";
		$_SESSION['username']= $uname;
		
        header('Location:index.php');
		
        exit();
	}
    }
    else{
        
		echo "<script>alert('Incorrect Password !');</script>" ;
       header('Location:login.php');
		exit();
    }
        
}
?>     
 


<!DOCTYPE html>
<html>
<head>
	<title> Login </title>
	<link rel="stylesheet" a href="css\style.css">
	<script src="https://www.google.com/recaptcha/api.js"></script>
	
</head>
<body>
	<div class="container">
	<img src="images/login.gif"/>
		<form method="POST" action="">
			<div class="form-input">
				<input type="text" name="username" placeholder="Enter the User Name"/>	
			</div>
			<div class="form-input">
				<input type="password" name="password" placeholder="password"/>
			</div>
			<div class="g-recaptcha" data-sitekey="6LeeJGMbAAAAADFuS0DvPglMoR8JgUwDpnFtNLlJ"></div>
			<input type="submit" name="submit" value="LOGIN" class="btn-login"/>
		</form>
	</div>

<?php
session_unset();
session_destroy();
?>
</body>
</html>