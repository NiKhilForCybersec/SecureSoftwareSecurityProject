<?php

session_start();
include 'database.php';
if(!isset($_SESSION['mid']))
{
    
    header('Location:merchant.php');
    
}
if (empty($_POST))

{
    header('Location:merchantadd.php');
}
$name = mysqli_real_escape_string($con,$_POST['pname']);
$name = strip_tags($name);
$desc = mysqli_real_escape_string($con,$_POST['pdesc']);
$price = mysqli_real_escape_string($con,$_POST['pprice']);

$allowedTypes = array("jpg","png");
$info = new SplFileInfo($_FILES['photo']['name']);
$ext = $info->getExtension();
$extname = strtolower($ext);
//echo $extname;
if (!in_array($extname, $allowedTypes))
{
        
    //$err[] = "Invalid File Extenestion";
    $a = $_SESSION['mid'];
    header('Location:merchantadd.php?mid='.$a);
    exit(0);
    
}


$id = $_SESSION['mid'];
$mname = $_SESSION['mname'];

if($_FILES['photo']['name'])
{
	//if no errors...
	if(!$_FILES['photo']['error'])
	{
            
            
                //now is the time to modify the future file name and validate the file
                $pname = $_FILES['photo']['name'];
                $ename = explode('.', $pname);
                $photoname = md5($ename[0]);
                $photoext = $ename[1];
                $fname = $photoname.".".$photoext;
                move_uploaded_file($_FILES['photo']['tmp_name'], 'pictures/'.$fname);
               
        }
}
$query = "insert into product(mname,pname,pdesc,pprice,pphoto,pext) values('$mname','$name','$desc','$price','$photoname','$photoext')";
    
$result = mysqli_query($con,$query);
    
if(!$result)
{
    echo "something went wrong";
    
}
 else {
     
    header('Location:product.php');
     
 }

 
?>